import { Button } from "./ui/button";
import { ExternalLink, TrendingUp, Dumbbell } from "lucide-react";
import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const Projects = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const projects = [
    {
      title: "StockPulse",
      subtitle: "AI-Powered Finance App",
      category: "Finance • AI",
      description:
        "StockPulse is a professional stock market analysis platform designed to simplify financial insights. It features real-time data visualization, trend forecasting using AI models, and an intuitive dashboard for quick decision-making.",
      icon: TrendingUp,
      link: "https://stock-fluence-84q13rv3b-abhishek-s-projects-fcd155d8.vercel.app/",
      accentColor: "accent",
    },
    {
      title: "FitLog",
      subtitle: "Your AI Fitness Companion",
      category: "Health • AI",
      description:
        "FitLog is an AI-powered fitness tracker designed to make your health journey smarter and more personalized. It helps users track workouts, monitor calories, log water intake, and receive intelligent fitness recommendations — all through a clean, futuristic interface.",
      icon: Dumbbell,
      link: "https://6904f15764239700810b6115--fitlo.netlify.app/",
      accentColor: "accent",
    },
  ];

  return (
    <section id="projects" className="py-32 bg-secondary dark:bg-background" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          {/* Title */}
          <motion.h2
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-orbitron font-black mb-16 text-foreground"
          >
            Featured <span className="accent-highlight">Projects</span>
          </motion.h2>

          {/* Projects Grid */}
          <div className="space-y-8">
            {projects.map((project, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 50 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.8, delay: 0.4 + index * 0.2 }}
                className="editorial-card p-10 md:p-12 group"
              >
                <div className="grid md:grid-cols-[auto,1fr] gap-8 md:gap-12">
                  {/* Icon Section */}
                  <div className="flex items-start">
                    <div className="bg-accent text-accent-foreground p-6 rounded-3xl group-hover:scale-110 group-hover:rotate-3 transition-all">
                      <project.icon className="w-16 h-16" />
                    </div>
                  </div>

                  {/* Content Section */}
                  <div className="space-y-6">
                    <div>
                      <span className="inline-block bg-secondary dark:bg-card px-4 py-2 rounded-full text-sm font-mono font-semibold mb-4 text-foreground">
                        {project.category}
                      </span>
                      <h3 className="text-4xl md:text-5xl font-orbitron font-black mb-2 text-foreground">
                        {project.title}
                      </h3>
                      <p className="text-xl font-inter font-semibold text-muted-foreground mb-4">
                        {project.subtitle}
                      </p>
                      <p className="text-lg font-inter text-foreground leading-relaxed">
                        {project.description}
                      </p>
                    </div>

                    <Button
                      size="lg"
                      onClick={() => window.open(project.link, "_blank")}
                      className="group/btn bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg font-bold rounded-2xl transition-all hover:scale-105"
                    >
                      View Demo
                      <ExternalLink className="ml-2 w-5 h-5 group-hover/btn:translate-x-1 group-hover/btn:-translate-y-1 transition-transform" />
                    </Button>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Projects;

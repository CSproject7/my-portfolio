import { motion } from "framer-motion";

const Footer = () => {
  return (
    <footer className="relative py-16 bg-primary dark:bg-background border-t-4 border-accent">
      {/* Animated Accent Line */}
      <motion.div
        initial={{ scaleX: 0 }}
        whileInView={{ scaleX: 1 }}
        transition={{ duration: 1 }}
        className="absolute top-0 left-0 right-0 h-1 bg-accent origin-left"
      />

      <div className="container mx-auto px-4 relative z-10">
        <div className="text-center space-y-6">
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-2xl font-orbitron font-bold text-foreground"
          >
            Copyright © 2025{" "}
            <span className="accent-highlight">Abhishek Pandey</span>
          </motion.p>
          <motion.p
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-lg font-inter text-muted-foreground"
          >
            Built with passion and powered by AI ✨
          </motion.p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;

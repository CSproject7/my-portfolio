import { useState } from "react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Textarea } from "./ui/textarea";
import { Mail, Github, Send } from "lucide-react";
import { toast } from "sonner";
import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const Contact = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });
  const [formData, setFormData] = useState({
    name: "",
    email: "",
    message: "",
  });

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    toast.success("Message sent! I'll get back to you soon.");
    setFormData({ name: "", email: "", message: "" });
  };

  const handleChange = (
    e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>
  ) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value,
    });
  };

  return (
    <section id="contact" className="py-32 bg-background dark:bg-primary" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          {/* Title */}
          <motion.h2
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-orbitron font-black mb-16 text-black"
          >
            Get in <span className="accent-highlight">Touch</span>
          </motion.h2>

          <div className="grid md:grid-cols-2 gap-12">
            {/* Contact Form */}
            <motion.div
              initial={{ opacity: 0, x: -30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.4 }}
            >
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Input
                    type="text"
                    name="name"
                    placeholder="Your Name"
                    value={formData.name}
                    onChange={handleChange}
                    required
                    className="h-14 text-lg rounded-2xl border-2 border-border focus:border-accent transition-colors"
                  />
                </div>
                <div>
                  <Input
                    type="email"
                    name="email"
                    placeholder="Your Email"
                    value={formData.email}
                    onChange={handleChange}
                    required
                    className="h-14 text-lg rounded-2xl border-2 border-border focus:border-accent transition-colors"
                  />
                </div>
                <div>
                  <Textarea
                    name="message"
                    placeholder="Your Message"
                    value={formData.message}
                    onChange={handleChange}
                    required
                    rows={6}
                    className="text-lg rounded-2xl border-2 border-border focus:border-accent transition-colors resize-none"
                  />
                </div>
                <Button
                  type="submit"
                  size="lg"
                  className="w-full group bg-primary hover:bg-primary/90 text-primary-foreground px-8 py-6 text-lg font-bold rounded-2xl transition-all hover:scale-105"
                >
                  Send Message
                  <Send className="ml-2 w-5 h-5 group-hover:translate-x-1 transition-transform" />
                </Button>
              </form>
            </motion.div>

            {/* Contact Info */}
            <motion.div
              initial={{ opacity: 0, x: 30 }}
              animate={isInView ? { opacity: 1, x: 0 } : {}}
              transition={{ duration: 0.8, delay: 0.6 }}
              className="space-y-8"
            >
              <div className="editorial-card p-8">
                <div className="flex items-start gap-6">
                  <div className="bg-accent text-accent-foreground p-4 rounded-2xl">
                    <Mail className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-orbitron font-bold mb-2 text-foreground">Email</h3>
                    <a
                      href="mailto:abhi797878@gmail.com"
                      className="text-lg font-inter text-muted-foreground hover:text-accent transition-colors"
                    >
                      abhi797878@gmail.com
                    </a>
                  </div>
                </div>
              </div>

              <div className="editorial-card p-8">
                <div className="flex items-start gap-6">
                  <div className="bg-accent text-accent-foreground p-4 rounded-2xl">
                    <Github className="w-8 h-8" />
                  </div>
                  <div>
                    <h3 className="text-2xl font-orbitron font-bold mb-2 text-foreground">GitHub</h3>
                    <a
                      href="https://github.com/abhi79780/abhi79780"
                      target="_blank"
                      rel="noopener noreferrer"
                      className="text-lg font-inter text-muted-foreground hover:text-accent transition-colors"
                    >
                      github.com/abhi79780
                    </a>
                  </div>
                </div>
              </div>

              <div className="editorial-card p-8 bg-white dark:bg-foreground">
                <p className="text-2xl font-orbitron font-bold mb-4 text-black">
                  Let's create something amazing together! 🚀
                </p>
                <p className="text-lg font-inter text-black">
                  I'm always open to discussing new projects, creative ideas, or
                  opportunities to be part of your vision.
                </p>
              </div>
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Contact;

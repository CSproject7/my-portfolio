import { Code, Brain } from "lucide-react";
import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const Skills = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const skillCategories = [
    {
      icon: Code,
      title: "Languages",
      skills: ["Python", "JavaScript", "MySQL", "R Programming", "Pandas"],
    },
    {
      icon: Brain,
      title: "AI Tools",
      skills: [
        "Lovable AI",
        "OpenAI",
        "Blackbox",
        "GitHub Copilot",
        "Cursor AI",
        "Trae AI",
        "N8N",
      ],
    },
  ];

  return (
    <section id="skills" className="py-32 bg-background dark:bg-primary" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          {/* Title */}
          <motion.h2
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-orbitron font-black mb-16 text-black"
          >
            <span className="accent-highlight">Skills</span> & Tools
          </motion.h2>

          {/* Skills Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
            {skillCategories.map((category, categoryIndex) => (
              <motion.div
                key={categoryIndex}
                initial={{ opacity: 0, scale: 0.9 }}
                animate={isInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.6, delay: 0.4 + categoryIndex * 0.2 }}
                className="editorial-card p-10 group"
              >
                <div className="flex items-center gap-4 mb-8">
                  <div className="bg-accent text-accent-foreground p-4 rounded-2xl group-hover:scale-110 transition-transform">
                    <category.icon className="w-10 h-10" />
                  </div>
                  <h3 className="text-3xl font-orbitron font-black text-foreground">{category.title}</h3>
                </div>

                <div className="flex flex-wrap gap-3">
                  {category.skills.map((skill, skillIndex) => (
                    <motion.span
                      key={skillIndex}
                      initial={{ opacity: 0, scale: 0.8 }}
                      animate={isInView ? { opacity: 1, scale: 1 } : {}}
                      transition={{
                        duration: 0.4,
                        delay: 0.6 + categoryIndex * 0.2 + skillIndex * 0.1,
                      }}
                      whileHover={{ scale: 1.1, rotate: 2 }}
                      className="bg-secondary dark:bg-background px-6 py-3 rounded-full font-inter font-semibold text-foreground border-2 border-border hover:border-accent transition-all cursor-default"
                    >
                      {skill}
                    </motion.span>
                  ))}
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default Skills;

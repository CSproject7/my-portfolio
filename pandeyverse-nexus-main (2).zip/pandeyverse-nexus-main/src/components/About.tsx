import { GraduationCap, Rocket, Trophy, Zap } from "lucide-react";
import { motion } from "framer-motion";
import { useInView } from "framer-motion";
import { useRef } from "react";

const About = () => {
  const ref = useRef(null);
  const isInView = useInView(ref, { once: true, margin: "-100px" });

  const timeline = [
    {
      icon: GraduationCap,
      title: "B.Sc. Computer Science",
      description: "Undergraduate Student",
      year: "2023-2026",
    },
    {
      icon: Rocket,
      title: "AI App Creator",
      description: "Building next-gen applications",
      year: "Present",
    },
    {
      icon: Zap,
      title: "Tech Enthusiast",
      description: "Exploring AI & Innovation",
      year: "Always",
    },
    {
      icon: Trophy,
      title: "Problem Solver",
      description: "Creating real-world solutions",
      year: "Ongoing",
    },
  ];

  return (
    <section id="about" className="py-32 bg-secondary dark:bg-background" ref={ref}>
      <div className="container mx-auto px-4">
        <motion.div
          initial={{ opacity: 0, y: 50 }}
          animate={isInView ? { opacity: 1, y: 0 } : {}}
          transition={{ duration: 0.8 }}
          className="max-w-6xl mx-auto"
        >
          {/* Title */}
          <motion.h2
            initial={{ opacity: 0, x: -50 }}
            animate={isInView ? { opacity: 1, x: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="text-5xl md:text-7xl font-orbitron font-black mb-8 text-foreground"
          >
            About <span className="accent-highlight">Me</span>
          </motion.h2>

          {/* Description */}
          <motion.div
            initial={{ opacity: 0, y: 30 }}
            animate={isInView ? { opacity: 1, y: 0 } : {}}
            transition={{ duration: 0.8, delay: 0.4 }}
            className="mb-16"
          >
            <p className="text-xl md:text-2xl font-inter leading-relaxed text-foreground max-w-4xl">
              Hi, I'm <span className="font-bold">Abhishek Pandey</span>, a passionate{" "}
              <span className="accent-highlight">AI app and tool creator</span> focused on
              building intelligent, next-generation applications that make technology smarter
              and more accessible.
            </p>
            <p className="text-xl md:text-2xl font-inter leading-relaxed text-muted-foreground mt-6 max-w-4xl">
              I specialize in AI-powered projects, combining creativity with technology to
              develop tools that solve real-world problems — from automation and analytics to
              personalized user experiences.
            </p>
            <p className="text-xl md:text-2xl font-inter font-semibold leading-relaxed text-foreground mt-6 max-w-4xl">
              💡 My goal is to build AI-driven tools that help people work faster, think
              smarter, and live better.
            </p>
          </motion.div>

          {/* Timeline Grid */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            {timeline.map((item, index) => (
              <motion.div
                key={index}
                initial={{ opacity: 0, y: 30 }}
                animate={isInView ? { opacity: 1, y: 0 } : {}}
                transition={{ duration: 0.6, delay: 0.6 + index * 0.1 }}
                className="editorial-card p-8 group"
              >
                <div className="flex items-start gap-6">
                  <div className="bg-accent text-accent-foreground p-4 rounded-2xl group-hover:scale-110 transition-transform">
                    <item.icon className="w-8 h-8" />
                  </div>
                  <div className="flex-1">
                    <div className="flex items-start justify-between mb-2">
                      <h3 className="text-2xl font-orbitron font-bold text-foreground">{item.title}</h3>
                      <span className="text-sm font-mono bg-secondary px-3 py-1 rounded-full text-foreground">
                        {item.year}
                      </span>
                    </div>
                    <p className="text-muted-foreground font-inter text-lg">
                      {item.description}
                    </p>
                  </div>
                </div>
              </motion.div>
            ))}
          </div>
        </motion.div>
      </div>
    </section>
  );
};

export default About;
